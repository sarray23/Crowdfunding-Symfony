<?php

/* EspritBackOfficeBundle:Default:index.html.twig */
class __TwigTemplate_bae98ae9f97f62c355e8d744ffc7de037e2a6b7a3fe946dc196f05577e3a454d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello
";
    }

    public function getTemplateName()
    {
        return "EspritBackOfficeBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* Hello*/
/* */
