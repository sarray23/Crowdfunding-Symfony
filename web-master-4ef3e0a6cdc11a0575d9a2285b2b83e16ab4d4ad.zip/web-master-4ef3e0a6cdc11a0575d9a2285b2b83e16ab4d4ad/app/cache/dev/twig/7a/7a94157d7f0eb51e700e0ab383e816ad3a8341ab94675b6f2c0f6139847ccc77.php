<?php

/* EspritBackOfficeBundle:Grids:grids.html.twig */
class __TwigTemplate_1c67c7bbdd20e40f756924d8e8b660afda1c405227c05710931b89e5f0408738 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("EspritBackOfficeBundle::layout.html.twig", "EspritBackOfficeBundle:Grids:grids.html.twig", 1);
        $this->blocks = array(
            'container' => array($this, 'block_container'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "EspritBackOfficeBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_container($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"graphs\">
\t   <div class=\"md\">
\t\t <h3>Grids</h3>
\t\t<div class=\"form-group\">
\t\t  <div class=\"row\">
\t\t\t<div class=\"col-md-12\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-12\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t   </div>
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-10\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-10\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-3 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-9\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-9\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"form-group\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-4 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-4\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-8\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-8\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t</div>\t
\t\t<div class=\"form-group\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-5 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-5\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-7\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-7\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t</div>\t
\t\t<div class=\"form-group\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-6 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-6\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-6\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-4 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-4\">
\t\t\t</div>
\t\t\t<div class=\"col-md-4 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-4\">
\t\t\t</div>
\t\t\t<div class=\"col-md-4\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-4\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-3 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"col-md-6 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-6\">
\t\t\t</div>
\t\t\t<div class=\"col-md-3\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t</div>
\t\t\t<div class=\"col-md-8 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-8\">
\t\t\t</div>
\t\t\t<div class=\"col-md-2\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-3 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"col-md-3 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"col-md-3 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"col-md-3\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-3\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group\">
\t\t<div class=\"row\">
\t\t\t<div class=\"col-md-5 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-5\">
\t\t\t</div>
\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t</div>
\t\t\t<div class=\"col-md-5\">
\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-5\">
\t\t\t</div>
\t\t\t<div class=\"clearfix\"> </div>
\t\t</div>
\t\t   </div>\t
\t\t   <div class=\"form-group mb-n\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2 grid_box1\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t<input type=\"text\" class=\"form-control1\" placeholder=\".col-md-2\">
\t\t\t\t</div>
\t\t\t\t<div class=\"clearfix\"> </div>
\t\t\t</div>
\t\t   </div>\t
        </div>\t
        <div class=\"copy_layout\">
         <p>Copyright © 2015 Modern. All Rights Reserved | Design by <a href=\"http://w3layouts.com/\" target=\"_blank\">W3layouts</a> </p>
        </div>\t\t\t\t\t
       </div>
";
    }

    public function getTemplateName()
    {
        return "EspritBackOfficeBundle:Grids:grids.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 3,  28 => 2,  11 => 1,);
    }
}
/* {%extends "EspritBackOfficeBundle::layout.html.twig"%}*/
/* {%block container %}*/
/* <div class="graphs">*/
/* 	   <div class="md">*/
/* 		 <h3>Grids</h3>*/
/* 		<div class="form-group">*/
/* 		  <div class="row">*/
/* 			<div class="col-md-12">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-12">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		   </div>*/
/* 		</div>*/
/* 		<div class="form-group">*/
/* 			<div class="row">*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-10">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-10">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		</div>*/
/* 		<div class="form-group">*/
/* 			<div class="row">*/
/* 				<div class="col-md-3 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 				</div>*/
/* 				<div class="col-md-9">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-9">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		</div>*/
/* 		<div class="form-group">*/
/* 			<div class="row">*/
/* 				<div class="col-md-4 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-4">*/
/* 				</div>*/
/* 				<div class="col-md-8">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-8">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		</div>	*/
/* 		<div class="form-group">*/
/* 			<div class="row">*/
/* 				<div class="col-md-5 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-5">*/
/* 				</div>*/
/* 				<div class="col-md-7">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-7">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		</div>	*/
/* 		<div class="form-group">*/
/* 			<div class="row">*/
/* 				<div class="col-md-6 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-6">*/
/* 				</div>*/
/* 				<div class="col-md-6">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-6">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group">*/
/* 		<div class="row">*/
/* 			<div class="col-md-4 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-4">*/
/* 			</div>*/
/* 			<div class="col-md-4 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-4">*/
/* 			</div>*/
/* 			<div class="col-md-4">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-4">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group">*/
/* 		<div class="row">*/
/* 			<div class="col-md-3 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="col-md-6 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-6">*/
/* 			</div>*/
/* 			<div class="col-md-3">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group">*/
/* 		<div class="row">*/
/* 			<div class="col-md-2 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 			</div>*/
/* 			<div class="col-md-8 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-8">*/
/* 			</div>*/
/* 			<div class="col-md-2">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group">*/
/* 		<div class="row">*/
/* 			<div class="col-md-3 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="col-md-3 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="col-md-3 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="col-md-3">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-3">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group">*/
/* 		<div class="row">*/
/* 			<div class="col-md-5 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-5">*/
/* 			</div>*/
/* 			<div class="col-md-2 grid_box1">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 			</div>*/
/* 			<div class="col-md-5">*/
/* 				<input type="text" class="form-control1" placeholder=".col-md-5">*/
/* 			</div>*/
/* 			<div class="clearfix"> </div>*/
/* 		</div>*/
/* 		   </div>	*/
/* 		   <div class="form-group mb-n">*/
/* 			<div class="row">*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-2 grid_box1">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="col-md-2">*/
/* 					<input type="text" class="form-control1" placeholder=".col-md-2">*/
/* 				</div>*/
/* 				<div class="clearfix"> </div>*/
/* 			</div>*/
/* 		   </div>	*/
/*         </div>	*/
/*         <div class="copy_layout">*/
/*          <p>Copyright © 2015 Modern. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>*/
/*         </div>					*/
/*        </div>*/
/* {%endblock%}*/
