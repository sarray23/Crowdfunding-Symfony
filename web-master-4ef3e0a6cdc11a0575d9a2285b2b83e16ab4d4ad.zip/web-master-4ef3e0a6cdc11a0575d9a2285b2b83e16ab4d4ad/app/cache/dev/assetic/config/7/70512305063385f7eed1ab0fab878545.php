<?php

// EspritFrontOfficeBundle:Registration:register.html.twig
return array (
);
