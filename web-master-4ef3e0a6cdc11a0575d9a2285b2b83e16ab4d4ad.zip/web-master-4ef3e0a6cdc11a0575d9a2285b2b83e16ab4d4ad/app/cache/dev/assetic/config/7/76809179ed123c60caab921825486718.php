<?php

// EspritFrontOfficeBundle::ideeTypeLayout.html.twig
return array (
);
