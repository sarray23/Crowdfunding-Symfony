<?php

// EspritFrontOfficeBundle:Resetting:reset_content.html.twig
return array (
);
