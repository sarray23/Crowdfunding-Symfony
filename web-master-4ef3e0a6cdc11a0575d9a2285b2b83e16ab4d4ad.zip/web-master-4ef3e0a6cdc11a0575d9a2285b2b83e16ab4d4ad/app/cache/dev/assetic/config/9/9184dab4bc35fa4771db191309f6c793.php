<?php

// EspritFrontOfficeBundle:STAT:Stat.html.twig
return array (
);
