<?php

// EspritFrontOfficeBundle:STAT:unifiedChart.html.twig
return array (
);
