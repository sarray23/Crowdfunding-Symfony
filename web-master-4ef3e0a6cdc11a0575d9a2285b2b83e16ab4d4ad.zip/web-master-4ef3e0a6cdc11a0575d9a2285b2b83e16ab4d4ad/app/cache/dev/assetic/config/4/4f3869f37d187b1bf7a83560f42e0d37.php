<?php

// EspritFrontOfficeBundle:Idee:affiche.html.twig
return array (
);
