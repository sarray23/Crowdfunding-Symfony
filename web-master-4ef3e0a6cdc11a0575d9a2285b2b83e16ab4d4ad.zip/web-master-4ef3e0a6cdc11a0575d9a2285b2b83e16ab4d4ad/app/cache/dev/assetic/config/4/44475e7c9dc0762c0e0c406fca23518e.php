<?php

// EspritFrontOfficeBundle:Resetting:email.txt.twig
return array (
);
