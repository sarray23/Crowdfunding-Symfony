<?php

// EspritFrontOfficeBundle:Idee:resultat.html.twig
return array (
);
