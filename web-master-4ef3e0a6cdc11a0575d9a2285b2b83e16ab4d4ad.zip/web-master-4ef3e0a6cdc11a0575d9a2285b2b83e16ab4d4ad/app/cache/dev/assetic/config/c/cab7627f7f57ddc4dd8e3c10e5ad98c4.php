<?php

// EspritFrontOfficeBundle::layout1.html.twig
return array (
);
