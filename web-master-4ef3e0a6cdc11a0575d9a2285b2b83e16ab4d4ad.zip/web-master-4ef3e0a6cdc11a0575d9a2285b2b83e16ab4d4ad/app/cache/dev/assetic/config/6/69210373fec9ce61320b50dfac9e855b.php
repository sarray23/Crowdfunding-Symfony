<?php

// FOSUserBundle:Profile:edit.html.twig
return array (
);
