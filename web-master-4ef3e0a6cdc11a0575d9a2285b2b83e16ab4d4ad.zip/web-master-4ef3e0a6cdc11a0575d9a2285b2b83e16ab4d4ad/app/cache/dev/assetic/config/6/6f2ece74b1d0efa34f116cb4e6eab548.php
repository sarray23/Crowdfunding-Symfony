<?php

// EspritFrontOfficeBundle:Registration:checkEmail.html.twig
return array (
);
