<?php

// EspritFrontOfficeBundle:STAT:pie.html.twig
return array (
);
