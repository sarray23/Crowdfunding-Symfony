<?php

// EspritFrontOfficeBundle:Idee:affiche2r.html.twig
return array (
);
