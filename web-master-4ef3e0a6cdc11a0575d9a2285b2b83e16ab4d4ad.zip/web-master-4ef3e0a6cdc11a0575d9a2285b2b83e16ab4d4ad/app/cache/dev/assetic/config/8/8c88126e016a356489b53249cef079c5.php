<?php

// EspritFrontOfficeBundle:ChangePassword:changePassword.html.twig
return array (
);
