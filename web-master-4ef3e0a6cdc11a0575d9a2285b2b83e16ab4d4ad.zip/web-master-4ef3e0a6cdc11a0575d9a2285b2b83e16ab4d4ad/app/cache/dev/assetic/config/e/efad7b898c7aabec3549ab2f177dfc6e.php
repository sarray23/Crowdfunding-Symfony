<?php

// EspritFrontOfficeBundle:forum:accueil.html.twig
return array (
);
