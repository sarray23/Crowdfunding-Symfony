<?php

// EspritFrontOfficeBundle:Projet:detailP.html.twig
return array (
);
