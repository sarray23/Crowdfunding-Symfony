<?php

// EspritFrontOfficeBundle:STAT:LineChart.html.twig
return array (
);
