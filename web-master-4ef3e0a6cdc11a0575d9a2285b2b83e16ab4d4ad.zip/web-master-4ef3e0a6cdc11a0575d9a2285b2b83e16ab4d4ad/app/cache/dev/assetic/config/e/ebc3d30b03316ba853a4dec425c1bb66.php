<?php

// EspritFrontOfficeBundle:Resetting:checkEmail.html.twig
return array (
);
