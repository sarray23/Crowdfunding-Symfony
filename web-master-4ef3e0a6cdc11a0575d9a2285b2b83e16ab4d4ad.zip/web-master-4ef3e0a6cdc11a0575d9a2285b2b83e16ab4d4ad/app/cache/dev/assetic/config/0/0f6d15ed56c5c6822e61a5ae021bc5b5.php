<?php

// EspritFrontOfficeBundle:Registration:email.txt.twig
return array (
);
