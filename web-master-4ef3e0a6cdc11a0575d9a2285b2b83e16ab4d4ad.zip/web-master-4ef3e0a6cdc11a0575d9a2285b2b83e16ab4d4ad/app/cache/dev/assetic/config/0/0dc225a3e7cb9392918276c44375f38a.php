<?php

// EspritFrontOfficeBundle:STAT:BarChart.html.twig
return array (
);
