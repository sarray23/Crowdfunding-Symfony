<?php

// FOSUserBundle:Group:list_content.html.twig
return array (
);
