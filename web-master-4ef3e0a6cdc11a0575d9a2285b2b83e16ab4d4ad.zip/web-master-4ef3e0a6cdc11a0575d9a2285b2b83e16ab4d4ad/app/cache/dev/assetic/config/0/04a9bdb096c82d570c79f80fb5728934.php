<?php

// EspritFrontOfficeBundle:STAT:histogramme.html.twig
return array (
);
