<?php

// EspritFrontOfficeBundle:ChangePassword:changePassword_content.html.twig
return array (
);
