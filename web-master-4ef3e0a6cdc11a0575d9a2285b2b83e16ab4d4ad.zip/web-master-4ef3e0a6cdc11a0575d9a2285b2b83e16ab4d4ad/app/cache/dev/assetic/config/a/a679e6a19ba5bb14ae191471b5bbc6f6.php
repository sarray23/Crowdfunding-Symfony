<?php

// EspritFrontOfficeBundle:Competence:update.html.twig
return array (
);
