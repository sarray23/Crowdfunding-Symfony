<?php

// EspritFrontOfficeBundle:Idee:generale.html.twig
return array (
);
