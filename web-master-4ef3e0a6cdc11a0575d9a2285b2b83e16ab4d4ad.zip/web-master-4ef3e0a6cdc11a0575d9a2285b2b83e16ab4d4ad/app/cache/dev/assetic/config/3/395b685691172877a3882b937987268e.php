<?php

// EspritFrontOfficeBundle:Projet:afficheMy.html.twig
return array (
);
